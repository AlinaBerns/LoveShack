package be.intecbrussel.Pearl.LoveSchack.shop;

import be.intecbrussel.Pearl.LoveSchack.mixables.Food;
import be.intecbrussel.Pearl.LoveSchack.mixables.fruits.Apple;
import be.intecbrussel.Pearl.LoveSchack.mixables.fruits.Banana;
import be.intecbrussel.Pearl.LoveSchack.mixables.fruits.Orange;

public class Main {
    public static void main(String[] args) {
        //test
        LoveSchack loveSchack = new LoveSchack();
        loveSchack.order();



    }
}
