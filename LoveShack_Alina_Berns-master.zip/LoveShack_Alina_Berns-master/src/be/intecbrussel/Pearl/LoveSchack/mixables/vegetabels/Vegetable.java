package be.intecbrussel.Pearl.LoveSchack.mixables.vegetabels;

import be.intecbrussel.Pearl.LoveSchack.mixables.Food;

public abstract class Vegetable extends Food {
    public Vegetable(double pricePerPiece) {
        super(pricePerPiece);
    }
}
