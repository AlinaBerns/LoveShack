package be.intecbrussel.Pearl.LoveSchack.mixables;

public interface Mixable {

    void mix();

}
