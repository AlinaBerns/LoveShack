package be.intecbrussel.Pearl.LoveSchack.mixables.fruits;

import be.intecbrussel.Pearl.LoveSchack.mixables.Food;

public abstract class Fruit extends Food {
    public Fruit(double pricePerPiece) {
        super(pricePerPiece);
    }

}
